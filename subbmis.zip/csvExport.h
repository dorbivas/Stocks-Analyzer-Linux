#pragma once
using namespace std;

#include <iostream>
#include <stdio.h>
#include <string>
#include <fstream>
#include <filesystem>

void editFileIntoCSVFornat();